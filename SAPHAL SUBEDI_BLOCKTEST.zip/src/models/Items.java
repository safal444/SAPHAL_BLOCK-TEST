package models;

public class Items {
    String name;
    int code;
    String brand;
    int price;
    String details;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDetails() {
        System.out.println("Item Name: "+this.name+"\nCCode: "+this.code+"\nBrand: "+this.brand+"\nPrice: Rs."+this.price+"\n\n");
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Items(String name, int code, String brand, int price) {
        this.name = name;
        this.code = code;
        this.brand = brand;
        this.price = price;
        this.details = details;
    }
}
