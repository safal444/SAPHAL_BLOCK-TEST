package models;

import java.util.ArrayList;

public class Orders {
    int orderId;
    ArrayList<Items> items1;

    public ArrayList<Items> getItems2() {
        return items2;
    }

    public void setItems2(ArrayList<Items> items2) {
        this.items2 = items2;
    }

    ArrayList<Items> items2;

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public ArrayList<Items> getItems1() {
        return items1;
    }

    public void setItems(ArrayList<Items> items1) {
        this.items1 = items1;
    }

    public Orders(int orderId, ArrayList<Items> items1, ArrayList<Items> items2) {
        this.orderId = orderId;
        this.items1 = items1;
        this.items2 = items2;
    }
}
