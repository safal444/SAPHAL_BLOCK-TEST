package models;

import java.util.ArrayList;

public class Users {
    String name;
    int id;
    ArrayList<Orders> order1;

    public ArrayList<Orders> getOrder2() {
        return order2;
    }

    public void setOrders2(ArrayList<Orders> order2) {
        this.order2 = order2;
    }

    ArrayList<Orders> order2;

    public String getDetails() {
        System.out.println("User name: "+this.name+"\nId: "+this.id+"\nOrders: "+this.order1+" and "+this.order2+"\n\n");
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    String details;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Orders> getOrder1() {
        return order1;
    }

    public void setOrders(ArrayList<Orders> order1) {
        this.order1 = order1;
    }

    public Users(String name, int id, ArrayList<Orders> items1, ArrayList<Orders> order2) {
        this.name = name;
        this.id = id;
        this.order1 = order1;
        this.order2 = order2;
    }
}
