import models.Items;
import models.Orders;
import models.Users;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Items i1 = new Items("Cool", 3427, "Levis", 1250);
        Items i2 = new Items("Casual", 3651, "D&D", 1460);
        Items i3 = new Items("Classy", 5678, "Magic", 2100);
        Items i4 = new Items("Hero", 2022, "Zara", 1690);
        Items i5 = new Items("Rich", 1001, "Gucci", 20450);

        ArrayList<Items> items1 = new ArrayList<Items>();
        ArrayList<Items> items2 = new ArrayList<Items>();
        ArrayList<Items> items3 = new ArrayList<Items>();
        ArrayList<Items> items4 = new ArrayList<Items>();

        items1.add(i1);
        items1.add(i2);
        items1.add(i3);
        items2.add(i4);
        items2.add(i5);

        items3.add(i5);
        items3.add(i4);
        items3.add(i3);
        items4.add(i2);
        items4.add(i1);

        i1.getDetails();
        i2.getDetails();
        i3.getDetails();
        i4.getDetails();
        i5.getDetails();

        //orders
        Orders o1 = new Orders(145, items1, items2);
        Orders o2 = new Orders(666, items3, items4);
        Orders o3 = new Orders(212, items3, items2);
        Orders o4 = new Orders(867, items1, items4);

        ArrayList<Orders> orders1 = new ArrayList<Orders>();
        ArrayList<Orders> orders2 = new ArrayList<Orders>();
        ArrayList<Orders> orders3 = new ArrayList<Orders>();
        ArrayList<Orders> orders4 = new ArrayList<Orders>();

        orders1.add(o1);
        orders1.add(o2);

        orders2.add(o3);
        orders2.add(o4);

        orders3.add(o4);
        orders3.add(o3);

        orders4.add(o2);
        orders4.add(o1);

        //users
        Users u1 = new Users("Ramu", 123, orders1, orders2);
        Users u2 = new Users("Harihar", 873, orders3, orders4);

        u1.getDetails();
        u2.getDetails();

    }
}